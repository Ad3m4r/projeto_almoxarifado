package br.edu.uniessa.almoxarifado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmoxarifadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
